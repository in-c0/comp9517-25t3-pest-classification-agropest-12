"""
IMPORTANT: If you want to run `orig_vs_q.py` files, you must first generate q_filtered datasets
using the second part of the `Dinov2_benchmarking_Q_scoring.ipynb` notebook.

Dinov2+LogisticRegression Original vs Q-Filtered datasets
Runs 3 experiments:
1) ORIGINAL
2) LIGHT Q-filtered
3) MODERATE Q-filtered

includes:
Training speed
Validation speed
Inference speed
Full timing logs saved to CSV

Run this first, then run `Ava-orig_vs_q_comparisons.py`.
"""

import os
import time
import csv
import json
import joblib
import torch
import numpy as np
from pathlib import Path
from PIL import Image
import torchvision.transforms as T
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (
    accuracy_score,
    precision_recall_fscore_support,
    confusion_matrix,
    roc_auc_score,
    average_precision_score,
)
from sklearn.preprocessing import label_binarize


DATASETS = {
    "original": Path(r"C:/Users/wldud/Downloads/agropest-12"),
    "q_light": Path(r"C:/Users/wldud/Downloads/archive_q_light"),
    "q_moderate": Path(r"C:/Users/wldud/Downloads/archive_q_mod"),
}

OUTPUT_ROOT = Path("experiment_outputs_dino")
OUTPUT_ROOT.mkdir(exist_ok=True)

DEVICE = "cuda" if torch.cuda.is_available() else "cpu"

# Load DINOv2 encoder once
dino = torch.hub.load("facebookresearch/dinov2", "dinov2_vits14").to(DEVICE)
dino.eval()

transform = T.Compose([
    T.Resize((224, 224)),
    T.ToTensor(),
    T.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225]),
])


def embed(img: Image.Image) -> np.ndarray:
    x = transform(img).unsqueeze(0).to(DEVICE)
    with torch.no_grad():
        f = dino(x)
    return f.squeeze().cpu().numpy()


def load_split(split_dir: Path):
    images = []
    labels = []
    paths = []

    img_dir = split_dir / "images"
    lab_dir = split_dir / "labels"

    for f in os.listdir(img_dir):
        if not f.lower().endswith((".jpg", ".png", ".jpeg")):
            continue

        img_path = img_dir / f
        lab_path = lab_dir / (f.rsplit(".", 1)[0] + ".txt")

        if not lab_path.exists():
            continue

        with open(lab_path, "r") as fp:
            ln = fp.readline().strip().split()

        if len(ln) < 1:
            continue

        cls = int(ln[0])
        images.append(Image.open(img_path).convert("RGB"))
        labels.append(cls)
        paths.append(str(img_path))

    return images, np.array(labels, dtype=int), paths


def run_pipeline(name: str, dataset_path: Path):
    out_dir = OUTPUT_ROOT / name
    out_dir.mkdir(parents=True, exist_ok=True)

    print("\n======== DINOv2 + Logistic Regression:", name, "========")

    timing = {}

    # ---- Load images & labels ----
    t0 = time.time()
    train_imgs, ytr, train_paths = load_split(dataset_path / "train")
    val_imgs, yva, val_paths   = load_split(dataset_path / "valid")
    test_imgs, yte, test_paths = load_split(dataset_path / "test")
    t1 = time.time()
    timing["data_loading_sec"] = t1 - t0

    num_classes = len(np.unique(ytr))

    # ---- Embeddings ----
    print("Computing DINO embeddings...")
    t0 = time.time()
    Xtr = np.array([embed(im) for im in train_imgs])
    Xva = np.array([embed(im) for im in val_imgs])
    Xte = np.array([embed(im) for im in test_imgs])
    t1 = time.time()
    timing["embedding_sec"] = t1 - t0

    # ---- Train classifier ----
    print("Training Logistic Regression...")
    clf = LogisticRegression(max_iter=3000, n_jobs=-1)
    t0 = time.time()
    clf.fit(Xtr, ytr)
    t1 = time.time()
    timing["train_sec"] = t1 - t0

    # ---- Validation inference (timing) ----
    t0 = time.time()
    _ = clf.predict(Xva)
    t1 = time.time()
    timing["val_inference_sec"] = t1 - t0
    timing["val_ms_per_image"] = (t1 - t0) / max(1, len(Xva)) * 1000

    # ---- Test inference ----
    t0 = time.time()
    y_pred = clf.predict(Xte)
    t1 = time.time()
    timing["test_inference_sec"] = t1 - t0
    timing["test_ms_per_image"] = (t1 - t0) / max(1, len(Xte)) * 1000

    # ---- Metrics ----
    acc = accuracy_score(yte, y_pred)
    prec, rec, f1, _ = precision_recall_fscore_support(
        yte, y_pred, average="macro", zero_division=0
    )

    # Probabilities for AUC + mAP
    probs = clf.predict_proba(Xte)
    y_true_bin = label_binarize(yte, classes=np.arange(num_classes))

    try:
        auc_macro = roc_auc_score(y_true_bin, probs, average="macro", multi_class="ovr")
    except ValueError:
        auc_macro = float("nan")

    try:
        mAP_macro = average_precision_score(y_true_bin, probs, average="macro")
    except ValueError:
        mAP_macro = float("nan")

    cm = confusion_matrix(yte, y_pred)
    np.savetxt(out_dir / "confusion_matrix.csv", cm, delimiter=",")

    # ---- SAVE LOGISTIC REGRESSION MODEL ----
    joblib.dump(clf, out_dir / "dino_logreg_model.pkl")

    # ============================================================
    # SAVE PREDICTIONS FOR MISCLASSIFICATION ANALYSIS
    # ============================================================
    np.save(out_dir / "predictions.npy", y_pred)
    np.save(out_dir / "labels.npy", yte)

    with open(out_dir / "paths.txt", "w") as f:
        for p in test_paths:
            f.write(str(p) + "\n")

    # ---- Save timings ----
    with open(out_dir / "timing.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["metric", "value"])
        for k, v in timing.items():
            w.writerow([k, v])

    # ---- Save metrics ----
    metrics = {
        "accuracy": acc,
        "precision_macro": prec,
        "recall_macro": rec,
        "f1_macro": f1,
        "auc_macro": auc_macro,
        "mAP_macro": mAP_macro,
        "num_classes": int(num_classes),
    }
    with open(out_dir / "metrics.json", "w") as f:
        json.dump(metrics, f, indent=4)

    print("Test Accuracy:", acc)
    print("Macro F1:", f1)
    print("Macro AUC:", auc_macro)
    print("Macro mAP:", mAP_macro)
    print("Saved to:", out_dir)


if __name__ == "__main__":
    for name, path in DATASETS.items():
        run_pipeline(name, path)
    print("\nDONE: DINOv2 pipelines.\n")
