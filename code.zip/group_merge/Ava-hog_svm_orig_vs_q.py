"""
IMPORTANT: If you want to run `orig_vs_q.py` files, you must first generate q_filtered datasets using the second part of the `Dinov2_benchmarking_Q_scoring.ipynb` notebook.

HOG+SVM Original vs Q-Filtered datasets
Runs 3 experiments:
1) ORIGINAL
2) LIGHT Q-filtered
3) MODERATE Q-filtered

includes:
Training speed
Validation speed
Inference speed
Full timing logs saved to CSV

Run this first, then run `Ava-orig_vs_q_comparisons.py`.
"""
import os
import time
import csv
import json
import joblib
import numpy as np
from pathlib import Path
from skimage.feature import hog
from sklearn.svm import LinearSVC
from sklearn.metrics import (
    accuracy_score,
    precision_recall_fscore_support,
    confusion_matrix,
    roc_auc_score,
    average_precision_score
)
from sklearn.preprocessing import label_binarize
from PIL import Image

# Dataset roots (same as YOLO)
DATASETS = {
    "original": Path(r"C:/Users/wldud/Downloads/agropest-12"),
    "q_light": Path(r"C:/Users/wldud/Downloads/archive_q_light"),
    "q_moderate": Path(r"C:/Users/wldud/Downloads/archive_q_mod"),
}

OUTPUT_ROOT = Path("experiment_outputs_hog_svm")
OUTPUT_ROOT.mkdir(exist_ok=True)


def load_images_labels(split_dir: Path):
    images = []
    labels = []
    img_dir = split_dir / "images"
    lab_dir = split_dir / "labels"

    for f in os.listdir(img_dir):
        if not f.lower().endswith((".jpg", ".png", ".jpeg")):
            continue

        img_path = img_dir / f
        label_path = lab_dir / (f.rsplit(".", 1)[0] + ".txt")
        if not label_path.exists():
            continue

        with open(label_path, "r") as fp:
            ln = fp.readline().strip().split()
        if len(ln) < 1:
            continue

        cls = int(ln[0])  # first object only
        img = Image.open(img_path).convert("L").resize((128, 128))
        images.append(np.array(img))
        labels.append(cls)

    return images, np.array(labels, dtype=int)


def extract_hog_batch(images):
    feats = []
    for img in images:
        f = hog(
            img,
            pixels_per_cell=(16, 16),
            cells_per_block=(2, 2),
            orientations=9,
            feature_vector=True,
        )
        feats.append(f)
    return np.array(feats, dtype=np.float32)


def run_pipeline(name: str, dataset_path: Path):
    out_dir = OUTPUT_ROOT / name
    out_dir.mkdir(parents=True, exist_ok=True)

    print("\n========== HOG+SVM:", name, "==========")

    timing = {}

    # ---- Load data ----
    t0 = time.time()
    Xtr_img, ytr = load_images_labels(dataset_path / "train")
    Xva_img, yva = load_images_labels(dataset_path / "valid")
    Xte_img, yte = load_images_labels(dataset_path / "test")
    t1 = time.time()
    timing["data_loading_sec"] = t1 - t0

    # ---- Extract HOG ----
    print("Extracting HOG features...")
    t0 = time.time()
    Xtr = extract_hog_batch(Xtr_img)
    Xva = extract_hog_batch(Xva_img)
    Xte = extract_hog_batch(Xte_img)
    t1 = time.time()
    timing["hog_extraction_sec"] = t1 - t0

    num_classes = len(np.unique(ytr))

    # ---- Train SVM ----
    print("Training Linear SVM...")
    clf = LinearSVC()
    t0 = time.time()
    clf.fit(Xtr, ytr)
    t1 = time.time()
    timing["train_sec"] = t1 - t0

    # ---- Validation inference (for timing only) ----
    t0 = time.time()
    _ = clf.predict(Xva)
    t1 = time.time()
    timing["val_inference_sec"] = t1 - t0
    timing["val_ms_per_image"] = (t1 - t0) / max(1, len(Xva)) * 1000

    # ---- Test inference ----
    t0 = time.time()
    y_pred = clf.predict(Xte)
    t1 = time.time()
    timing["test_inference_sec"] = t1 - t0
    timing["test_ms_per_image"] = (t1 - t0) / max(1, len(Xte)) * 1000

    # ---- Metrics ----
    acc = accuracy_score(yte, y_pred)
    prec, rec, f1, _ = precision_recall_fscore_support(
        yte, y_pred, average="macro", zero_division=0
    )

    # For AUC + mAP we need score per class (use decision_function)
    scores = clf.decision_function(Xte)  # shape [N, C]
    if num_classes == 2:
        # make it (N,2)
        scores = np.column_stack([-scores, scores])

    y_true_bin = label_binarize(yte, classes=np.arange(num_classes))

    try:
        auc_macro = roc_auc_score(y_true_bin, scores, average="macro", multi_class="ovr")
    except ValueError:
        auc_macro = float("nan")

    # mAP (mean average precision over classes)
    try:
        mAP = average_precision_score(y_true_bin, scores, average="macro")
    except ValueError:
        mAP = float("nan")

    cm = confusion_matrix(yte, y_pred)
    np.savetxt(out_dir / "confusion_matrix.csv", cm, delimiter=",")

    # ---- Save model ----
    joblib.dump(clf, out_dir / "hog_svm_model.pkl")

    # ---- Save timings ----
    with open(out_dir / "timing.csv", "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(["metric", "value"])
        for k, v in timing.items():
            w.writerow([k, v])

    # ---- Save metrics ----
    metrics = {
        "accuracy": acc,
        "precision_macro": prec,
        "recall_macro": rec,
        "f1_macro": f1,
        "auc_macro": auc_macro,
        "mAP_macro": mAP,
        "num_classes": int(num_classes),
    }
    with open(out_dir / "metrics.json", "w") as f:
        json.dump(metrics, f, indent=4)

    print("Test Accuracy:", acc)
    print("Macro F1:", f1)
    print("Macro AUC:", auc_macro)
    print("Macro mAP:", mAP)
    print("Saved to:", out_dir)


if __name__ == "__main__":
    for name, path in DATASETS.items():
        run_pipeline(name, path)
    print("\nDONE: HOG+SVM pipelines\n")
