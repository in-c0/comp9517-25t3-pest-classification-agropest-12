"""
IMPORTANT: If you want to run `orig_vs_q.py` files, you must first generate q_filtered datasets using the second part of the `Dinov2_benchmarking_Q_scoring.ipynb` notebook.

Aggregates YOLOv8, HOG+SVM, and DINOv2 metrics into one unified table.

Outputs:
- comparison_summary.csv
- comparison_summary.json
- comparison_summary_pretty.txt

Run the three other orig_vs_q scripts first in any order, 
and THEN run this script afterwards.
"""

import os
import json
import csv
from pathlib import Path
import pandas as pd

METHOD_FOLDERS = {
    "yolo": Path("experiment_outputs"),
    "hog_svm": Path("experiment_outputs_hog_svm"),
    "dino": Path("experiment_outputs_dino"),
}

OUTPUT_CSV = "comparison_summary.csv"
OUTPUT_JSON = "comparison_summary.json"
OUTPUT_TXT  = "comparison_summary_pretty.txt"


def load_metrics_json(path: Path):
    """Load metrics.json if exists."""
    f = path / "metrics.json"
    if f.exists():
        return json.load(open(f, "r"))
    return {}


def load_timing_csv(path: Path):
    """Load timing.csv if exists."""
    f = path / "timing.csv"
    if not f.exists():
        return {}
    data = {}
    with open(f, "r") as fp:
        r = csv.reader(fp)
        next(r)  # header
        for k, v in r:
            try:
                data[k] = float(v)
            except:
                data[k] = v
    return data


def extract_dataset_folders(base_dir: Path):
    """
    Base directory structure example:
        experiment_outputs/
            original/
            q_light/
            q_moderate/
    Returns list of dataset subfolders.
    """
    subs = []
    for d in base_dir.iterdir():
        if d.is_dir():
            subs.append(d)
    return subs

records = []

for method_name, method_root in METHOD_FOLDERS.items():

    if not method_root.exists():
        print(f"WARNING: Missing folder: {method_root}")
        continue

    dataset_dirs = extract_dataset_folders(method_root)

    for ds_dir in dataset_dirs:

        metrics = load_metrics_json(ds_dir)
        timing  = load_timing_csv(ds_dir)
        record  = {
            "method": method_name,
            "dataset": ds_dir.name,
        }

        # Add all metrics.json values
        for k, v in metrics.items():
            record[k] = v

        # Add timings
        for k, v in timing.items():
            record[k] = v

        records.append(record)

df = pd.DataFrame(records)

df.to_csv(OUTPUT_CSV, index=False)
df.to_json(OUTPUT_JSON, orient="records", indent=4)

# Human-readable text file
with open(OUTPUT_TXT, "w") as f:
    f.write(df.to_string(index=False))

print("  Comparison summary generated")
print(f"CSV {OUTPUT_CSV}")
print(f"JSON {OUTPUT_JSON}")
print(f"TXT {OUTPUT_TXT}\n")
print(df)
