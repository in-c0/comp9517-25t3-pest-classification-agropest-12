"""
IMPORTANT: If you want to run `orig_vs_q.py` files, you must first generate q_filtered datasets using the second part of the `Dinov2_benchmarking_Q_scoring.ipynb` notebook.

YOLOv8 Original vs Q-Filtered datasets
Runs 3 experiments:
1) ORIGINAL
2) LIGHT Q-filtered
3) MODERATE Q-filtered

includes:
Training speed
Validation speed
Inference speed
Full timing logs saved to CSV
"""

import os
import time
import csv
import json
from pathlib import Path
from ultralytics import YOLO

BASE_MODEL = "yolov8n.pt"

DATASETS = {
    "original": Path(r"C:/Users/wldud/Downloads/agropest-12"),
    "q_light": Path(r"C:/Users/wldud/Downloads/archive_q_light"),
    "q_moderate": Path(r"C:/Users/wldud/Downloads/archive_q_mod"),
}

OUTPUT_ROOT = Path("experiment_outputs")
OUTPUT_ROOT.mkdir(exist_ok=True)

def find_best_model(out_dir: Path):
    """
    Returns best.pt even if YOLO creates train2/train3/... due to exist_ok=False.
    """
    fixed = out_dir / "train" / "weights" / "best.pt"

    if fixed.exists():
        return fixed
    runs = [d for d in out_dir.iterdir() if d.is_dir() and d.name.startswith("train")]
    if not runs:
        raise FileNotFoundError(f"No YOLO run folders found inside {out_dir}")
    
    latest = sorted(runs, key=lambda x: x.stat().st_mtime)[-1]
    best = latest / "weights" / "best.pt"

    if not best.exists():
        raise FileNotFoundError(f"best.pt not found in: {latest}")
    print(f"best.pt not found in train/, using: {best}")

    return best

def run_pipeline(name, dataset_path):

    print(f"STARTING PIPELINE {name.upper()}")

    data_yaml = dataset_path / "data.yaml"
    train_imgs = dataset_path / "train"
    valid_imgs = dataset_path / "valid"
    test_imgs = dataset_path / "test"

    OUT_DIR  = OUTPUT_ROOT / name
    CM_DIR   = OUT_DIR / "confusion_matrix"
    ATTN_DIR = OUT_DIR / "attention"
    CAM_DIR  = OUT_DIR / "gradcam"

    for d in [OUT_DIR, CM_DIR, ATTN_DIR, CAM_DIR]:
        d.mkdir(parents=True, exist_ok=True)

    timing = {}

    print("Skipping training — loading best model...")
    best_model_path = find_best_model(OUT_DIR)
    print("Using:", best_model_path)

    model = YOLO(str(best_model_path))

    # -------------------------
    # VALIDATION
    # -------------------------
    print("Running validation...")
    t0 = time.time()
    val_results = model.val()
    t1 = time.time()

    timing["validation_total_sec"] = t1 - t0

    num_val_images = len(list((valid_imgs / "images").glob("*")))
    timing["validation_ms_per_image"] = (t1 - t0) / num_val_images * 1000 if num_val_images else None

    # Metrics
    metrics = val_results.results_dict
    P = metrics["metrics/precision(B)"]
    R = metrics["metrics/recall(B)"]
    f1 = 2 * P * R / (P + R + 1e-16)

    metrics_full = {
        "precision": float(P),
        "recall": float(R),
        "f1": float(f1),
        "mAP50": float(metrics["metrics/mAP50(B)"]),
        "mAP50_95": float(metrics["metrics/mAP50-95(B)"]),
    }

    print("\nVALIDATION METRICS:")
    for k, v in metrics_full.items():
        print(f"{k}: {v}")

    # Save confusion matrix
    cm = val_results.confusion_matrix
    cm.plot(save_dir=CM_DIR)

    # -------------------------
    # TEST INFERENCE
    # -------------------------
    print("Running test set inference...")
    test_image_dir = test_imgs / "images"
    test_images = list(test_image_dir.glob("*"))

    t0 = time.time()
    model.predict(
        source=str(test_image_dir),
        save=True,
        project=str(OUT_DIR),
        name="test_predictions"
    )
    t1 = time.time()

    timing["test_inference_total_sec"] = t1 - t0
    timing["test_inference_ms_per_image"] = (t1 - t0) / len(test_images) * 1000 if test_images else None

    # -------------------------
    # FEATURE VISUALIZATION
    # -------------------------
    print("Saving feature maps...")
    val_image_dir = valid_imgs / "images"

    t0 = time.time()
    model.predict(
        source=str(val_image_dir),
        save=True,
        visualize=True,
        project=str(ATTN_DIR),
        name="features"
    )
    t1 = time.time()
    timing["feature_map_inference_sec"] = t1 - t0

    # -------------------------
    # GRAD–CAM
    # -------------------------
    print("Saving Grad-CAM...")
    t0 = time.time()
    model.predict(
        source=str(val_image_dir),
        save=True,
        save_cam=True,
        project=str(CAM_DIR),
        name="cam"
    )
    t1 = time.time()
    timing["gradcam_inference_sec"] = t1 - t0

    # -------------------------
    # SAVE METRICS & TIMINGS
    # -------------------------
    with open(OUT_DIR / "metrics.json", "w") as f:
        json.dump(metrics_full, f, indent=4)

    with open(OUT_DIR / "timing.csv", "w", newline="") as f:
        writer = csv.writer(f)
        writer.writerow(["metric", "value"])
        for k, v in timing.items():
            writer.writerow([k, v])

    print("\nSaved metrics and timings.")


if __name__ == "__main__":
    import multiprocessing
    multiprocessing.freeze_support()

    for dataset_name, dataset_path in DATASETS.items():
        run_pipeline(dataset_name, dataset_path)