# AgroPest-12 Group Project (COMP9517,Term 3, 2025) - Group 201

This repository contains all code, experiments, and analysis produced by our group for the COMP9517 project on `AgroPest-12`, a 12-class insect and crop-pest image classification task. The aim of the project is to evaluate a wide range of computer-vision and machine-learning approaches -- from classical models to deep learning feature extractors -- and compare how well they classify pest species in challenging real-world images.

Our submission also includes a 10-minute presentation video and a written report, which together provide the full explanation of our methods and results.

---

## File Overview

### Ava

* `Ava-Dinov2_benchmarking_Q_scoring.ipynb`
* `Ava-negative_finetuning.ipynb`
* `Ava-orig_vs_q_comparisons.py`
* `Ava-dinov2_orig_vs_q.py`
* `Ava-hog_svm_orig_vs_q.py`
* `Ava-yolo_orig_vs_q.py`
* `collect_misclassified.py`
* `q-scoring.txt`

### Jeremy

* `Group201_COMP9517_25T3_Group_Project_v0.93.ipynb`
  * Classical ML baselines (HOG+SVM +LBP/HSV/GLCM/ORB/mobileSAM)


### James

* `COMP9517_Group_James.ipynb`

  1. YOLO v8n
  2. Faster R-CNN with ResNet50
  3. Faster R-CNN with Mobilenet


---

## External Libraries

Frameworks & Libraries
- PyTorch – https://pytorch.org/
  - torch.load(): https://docs.pytorch.org/docs/stable/generated/torch.load.html
- Torchvision – https://pytorch.org/vision
  - Transforms reference: https://docs.pytorch.org/vision/0.8/transforms.html
  - Normalization statistics: ImageNet_Normalize.py (https://gist.github.com/sariabod/39a0e6309a6a7a4e89f46ce839043688)
- Albumentations – https://albumentations.ai/

Pre-trained / Research Models
- DINOv2 – https://github.com/facebookresearch/dinov2
  - Example notebooks: depth_estimation.ipynb, dinotxt.ipynb, semantic_segmentation.ipynb
- U²-Net – https://github.com/xuebinqin/U-2-Net
- Segment Anything Model (SAM) – https://github.com/facebookresearch/segment-anything
- MobileSAM – https://github.com/ChaoningZhang/MobileSAM
- Ultralytics YOLOv8 – https://github.com/ultralytics/ultralytics

---

## References (for the code)

* Rupankar Majumdar, *AgroPest-12: A 12-Class Image Dataset of Crop Insects and Pests*, Kaggle (2025): [https://www.kaggle.com/datasets/rupankarmajumdar/crop-pests-dataset](https://www.kaggle.com/datasets/rupankarmajumdar/crop-pests-dataset)

* scikit-learn documentation (Logistic Regression, SVM, MLP, metrics): [https://scikit-learn.org/](https://scikit-learn.org/)

* Linear SVM: [https://scikit-learn.org/stable/modules/svm.html](https://scikit-learn.org/stable/modules/svm.html)

* MLP (feed-forward neural net): [https://scikit-learn.org/stable/modules/neural_networks_supervised.html](https://scikit-learn.org/stable/modules/neural_networks_supervised.html)

* F1 score reference: [https://github.com/ultralytics/ultralytics/issues/3875](https://github.com/ultralytics/ultralytics/issues/3875)

* YOLO bounding-box format (cx, cy, w, h -> xyxy), Redmon et al. (2016): [https://arxiv.org/abs/1506.02640](https://arxiv.org/abs/1506.02640)

* YOLOv11n baseline GitHub/Colab: [https://github.com/in-c0/AgroPest-12-YOLOv11/tree/main](https://github.com/in-c0/AgroPest-12-YOLOv11/tree/main)

* Cosine similarity: [https://en.wikipedia.org/wiki/Cosine_similarity](https://en.wikipedia.org/wiki/Cosine_similarity)

* k-means clustering (Lloyd, 1982): [https://en.wikipedia.org/wiki/K-means_clustering](https://en.wikipedia.org/wiki/K-means_clustering)

* Mahalanobis distance: [https://en.wikipedia.org/wiki/Mahalanobis_distance](https://en.wikipedia.org/wiki/Mahalanobis_distance)

* Euclidean (L2) distance: [https://en.wikipedia.org/wiki/Euclidean_distance](https://en.wikipedia.org/wiki/Euclidean_distance)

* Kernel Density Estimation (Rosenblatt, 1956; Parzen, 1962): [https://en.wikipedia.org/wiki/Kernel_density_estimation](https://en.wikipedia.org/wiki/Kernel_density_estimation)

* ECDF (Empirical Distribution Function): [https://en.wikipedia.org/wiki/Empirical_distribution_function](https://en.wikipedia.org/wiki/Empirical_distribution_function)

* *Why Less is More* (2025): [https://arxiv.org/abs/2511.03492](https://arxiv.org/abs/2511.03492)
* Depth Anything 3: [https://depth-anything-3.github.io/](https://depth-anything-3.github.io/)

* Application of artificial intelligence in insect pest identification – A review (2026)
  Sourav Chakrabarty et al.
  Artificial Intelligence in Agriculture, Vol. 16(1), 44–61.
  [https://www.sciencedirect.com/science/article/pii/S2589721725000686?via%3Dihub](https://www.sciencedirect.com/science/article/pii/S2589721725000686?via%3Dihub)

* Machine learning for image‑based species identification (2018)
  Jana Wäldchen & Patrick Mäder
  Methods in Ecology and Evolution.
  [https://besjournals.onlinelibrary.wiley.com/doi/epdf/10.1111/2041-210X.13075](https://besjournals.onlinelibrary.wiley.com/doi/epdf/10.1111/2041-210X.13075)

* AP162: A large‑scale dataset for agricultural pest recognition (2025)
  Kaili Wang et al.
  Computers and Electronics in Agriculture, Vol. 237 (Part B).
  [https://www.sciencedirect.com/science/article/abs/pii/S016816992500626X?via%3Dihub](https://www.sciencedirect.com/science/article/abs/pii/S016816992500626X?via%3Dihub)

* Machine learning‑based approaches for tomato pest classification (2022)
  Gayatri Pattnaik & Kodimala Parvathi
  TELKOMNIKA Telecommunication Computing Electronics and Control.
  [https://www.proquest.com/openview/4d88134e402de4bc9fe03c2174056f12/1?pq-origsite=gscholar&cbl=376296](https://www.proquest.com/openview/4d88134e402de4bc9fe03c2174056f12/1?pq-origsite=gscholar&cbl=376296)

* Detection of pests in agriculture using machine learning (2024)
  Emma Olsson
  Agtech Sweden, Linköping University.
  [https://www.diva-portal.org/smash/get/diva2:1947258/FULLTEXT01.pdf](https://www.diva-portal.org/smash/get/diva2:1947258/FULLTEXT01.pdf)

### Negative sample datasets (Roboflow)

* Soil dataset: [https://universe.roboflow.com/a-w3qhv/soil-type-ladmq-iotjp/dataset/1](https://universe.roboflow.com/a-w3qhv/soil-type-ladmq-iotjp/dataset/1)
* Weed dataset: [https://app.roboflow.com/a-w3qhv/weeds-rkmym-dyilb/1/images](https://app.roboflow.com/a-w3qhv/weeds-rkmym-dyilb/1/images)
* Crop dataset: [https://app.roboflow.com/a-w3qhv/agricultural-crop-nk6wd-pxnvk/1/](https://app.roboflow.com/a-w3qhv/agricultural-crop-nk6wd-pxnvk/1/)
* Leaf dataset: [https://universe.roboflow.com/leaf-w2m9j/leaf-rhr7e](https://universe.roboflow.com/leaf-w2m9j/leaf-rhr7e)
* Unsupervised seed extraction example paper: [https://besjournals.onlinelibrary.wiley.com/doi/10.1111/2041-210X.14127](https://besjournals.onlinelibrary.wiley.com/doi/10.1111/2041-210X.14127)


