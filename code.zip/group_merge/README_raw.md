
# Credit & References


Rupankar Majumdar, "AgroPest-12: A 12-Class Image Dataset of Crop Insects and Pests," Kaggle, 2025 https://www.kaggle.com/datasets/rupankarmajumdar/crop-pests-dataset


Logistic Regression, SVM, MLP, Confusion Matrix, Precision, Recall, F1, ROC-AUC, mAP - https://scikit-learn.org/

Linear SVM:
https://scikit-learn.org/stable/modules/svm.html

MLP (feed-forward neural net):
https://scikit-learn.org/stable/modules/neural_networks_supervised.html/

F1 Score formula https://github.com/ultralytics/ultralytics/issues/3875 

YOLO Bounding-Box Format (cx, cy, w, h → xyxy) (Redmon et al., 2016) – https://arxiv.org/abs/1506.02640
Cosine Similarity / Standard vector similarity measure https://en.wikipedia.org/wiki/Cosine_similarity
k-means class centroids: Lloyd, S. (1982). Least squares quantization in PCM https://en.wikipedia.org/wiki/K-means_clustering/

Mahalanobis Distance Mahalanobis, P. C. (1936).
https://en.wikipedia.org/wiki/Mahalanobis_distance

L2 distance Reference:
https://en.wikipedia.org/wiki/Euclidean_distance/

Kernel Density Estimation Rosenblatt, M. (1956), Parzen (1962)
https://en.wikipedia.org/wiki/Kernel_density_estimation/

ECDF Reference: https://en.wikipedia.org/wiki/Empirical_distribution_function/

YOLOv11n Baseline Github/Colab: github.com/in-c0/AgroPest-12-YOLOv11/tree/main/



## Libraries


U²-Net – https://github.com/xuebinqin/U-2-Net
facebook SAM https://github.com/facebookresearch/segment-anything
Segment Anything Model (SAM) – https://github.com/facebookresearch/segment-anything
Ultralytics YOLOv8 – https://github.com/ultralytics/ultralytics/

Torch https://docs.pytorch.org/docs/stable/generated/torch.load.html
Torchvision https://docs.pytorch.org/vision/0.8/transforms.html
Dinov2 https://github.com/facebookresearch/dinov2
ImageNet_Normalize.py https://gist.github.com/sariabod/39a0e6309a6a7a4e89f46ce839043688

PyTorch – https://pytorch.org/
NumPy – https://numpy.org/
scikit-learn – https://scikit-learn.org/stable/
Pillow (PIL) – https://python-pillow.org/
joblib – https://joblib.readthedocs.io/
Python standard library docs – https://docs.python.org/3/library/
OpenCV (cv2) – https://opencv.org/
tqdm – https://github.com/tqdm/tqdm/


1) Application of artificial intelligence in insect pest identification - A review - https://www.sciencedirect.com/science/article/pii/S2589721725000686?via%3Dihub
    * by Sourav Chakrabarty, Chandan Kumar Deb, Sudeep Marwaha, Md. Ashraful Haque, Deeba Kamil, Raju Bheemanahalli, Pathour Rajendra Shashank 2024
    * published: Artificial Intelligence in Agriculture Volume 16, Issue 1, March 2026, Pages 44-61

2) Machine learning for image based species identification - https://besjournals.onlinelibrary.wiley.com/doi/epdf/10.1111/2041-210X.13075?getft_integrator=sciencedirect_contenthosting&src=getftr&utm_source=sciencedirect_contenthosting
    * by Jana Wäldchen, Patrick Mäder
    * published: Methods in Ecology andEvolution © 2018 British Ecological Society, 2018

3) AP162: A large-scale dataset for agricultural pest recognition - https://www.sciencedirect.com/science/article/abs/pii/S016816992500626X?via%3Dihub
    * by Kaili Wang, Wei Li, Xiao Wu, Jingwen Xu, Zhi-Wen Wang, Siyu Yang
    * published: Computers and Electronics in Agriculture Volume 237, Part B, October 2025, 110520

4) Machine learning-based approaches for tomato pest classification - https://www.proquest.com/openview/4d88134e402de4bc9fe03c2174056f12/1?pq-origsite=gscholar&cbl=376296
    * by Gayatri Pattnaik1, Kodimala Parvathi
    * published: TELKOMNIKA Telecommunication Computing Electronics and Control, Feb 2022

5) Detection of pests in agriculture using machine learning
https://www.diva-portal.org/smash/get/diva2:1947258/FULLTEXT01.pdf
    * by Emma Olsson
    * published: Agtech Sweden c/o Linköping University, 2024

```bash

# References used in the slides
```

Why less is more: https://arxiv.org/abs/2511.03492
Depth Anything 3: https://depth-anything-3.github.io/

Negative samples datasets:
Soil: https://universe.roboflow.com/a-w3qhv/soil-type-ladmq-iotjp/dataset/1
Weed : https://app.roboflow.com/a-w3qhv/weeds-rkmym-dyilb/1/images
Crop : https://app.roboflow.com/a-w3qhv/agricultural-crop-nk6wd-pxnvk/1/
Leaf: https://universe.roboflow.com/leaf-w2m9j/leaf-rhr7e
Unsupervised Seed Extraction example paper https://besjournals.onlinelibrary.wiley.com/doi/10.1111/2041-210X.14127
```

# Core libraries
numpy
matplotlib
opencv-python

# Augmentation
albumentations

# Machine Learning
scikit-learn
scikit-image
joblib
mean-average-precision

# Visualization
seaborn
Pillow

# Segment Anything Model (mobileSAM)
segment-anything
git+https://github.com/ChaoningZhang/MobileSAM.git
```

---
```text
torch
- torch.load()
torchvision
- transforms()

Statistics for torchvision.transforms().Normalize()
- ImageNet_Normalize.py

Dinov2
- notebooks/
    - depth_estimation.ipynb
    - dinotxt.ipynb
    - semantic_segmentation.ipynb

```
----



Please read our paper's Biblication for more paper-related references.