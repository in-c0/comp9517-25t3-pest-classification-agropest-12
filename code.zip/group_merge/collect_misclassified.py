import numpy as np
from pathlib import Path
from sklearn.metrics import accuracy_score
import shutil
import json
import torch

DATASETS = {
    "original": Path(r"C:/Users/wldud/Downloads/agropest-12"),
    "q_light": Path(r"C:/Users/wldud/Downloads/archive_q_light"),
    "q_moderate": Path(r"C:/Users/wldud/Downloads/archive_q_mod"),
}

OUTPUT_ROOT = Path("experiment_outputs_dino")


def load_predictions(dataset_name):
    """Loads stored DINO predictions, labels, and image paths."""

    pred_file = OUTPUT_ROOT / dataset_name / "predictions.npy"
    true_file = OUTPUT_ROOT / dataset_name / "labels.npy"
    paths_file = OUTPUT_ROOT / dataset_name / "paths.txt"

    if not pred_file.exists():
        raise FileNotFoundError(f"No predictions for {dataset_name}")

    preds = np.load(pred_file)
    labels = np.load(true_file)
    paths = [line.strip() for line in open(paths_file, "r").readlines()]

    return preds, labels, paths


def collect_misclassified(dataset_name):
    print(f"\n=========== {dataset_name.upper()} ===========")

    preds, labels, paths = load_predictions(dataset_name)
    preds = preds.astype(int)
    labels = labels.astype(int)

    incorrect_idx = np.where(preds != labels)[0]
    print(f"Incorrect predictions: {len(incorrect_idx)}")

    # Output folder
    out_dir = OUTPUT_ROOT / dataset_name / "misclassified"
    out_dir.mkdir(exist_ok=True)

    # Load class index mapping
    class_names = [d.name for d in sorted(DATASETS[dataset_name].glob("train/*"))]

    for i in incorrect_idx:
        src_path = Path(paths[i])
        pred_class = class_names[preds[i]]
        true_class = class_names[labels[i]]

        # output filename
        new_name = f"{src_path.stem}_pred={pred_class}_true={true_class}{src_path.suffix}"
        dst_path = out_dir / new_name

        shutil.copy(src_path, dst_path)

    print(f"Saved misclassified images → {out_dir}")


def main():
    for dataset in DATASETS:
        collect_misclassified(dataset)


if __name__ == "__main__":
    main()
